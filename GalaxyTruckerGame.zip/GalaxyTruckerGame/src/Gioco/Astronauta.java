package Gioco;

public class Astronauta {
	private Colore giocatoreAssegnato;
	private boolean disponibile;
	
	public Astronauta() {
		this.disponibile = true;
		this.giocatoreAssegnato = null;
	}
}
