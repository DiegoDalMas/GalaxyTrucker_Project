package Gioco;

public class Batteria {
	private Colore giocatoreAssegnato;
	private boolean disponibile;
	
	public Batteria() {
		this.disponibile = true;
		this.giocatoreAssegnato = null;
	}
}