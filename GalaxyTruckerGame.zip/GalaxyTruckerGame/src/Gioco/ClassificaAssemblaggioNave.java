package Gioco;

public enum ClassificaAssemblaggioNave {
	PRIMO, SECONDO, TERZO, QUARTO;
}