package Gioco;

public enum Colore {
	BLU, VERDE, GIALLO, ROSSO;
}
