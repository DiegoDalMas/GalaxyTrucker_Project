package Gioco;

public enum Livello {
	UNO, DUE, TRE;
}
