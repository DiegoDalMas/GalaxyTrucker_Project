package Gioco;

public class Tabellone {
	private Casella[] caselle;
	private Livello livelloNave;
	private boolean[] spazioCasellaExtra;	//caselle extra in alto a destra
	private static Colore colore;
	
	
	
	
	
	
	//public void aumentaLivelloNave();
}