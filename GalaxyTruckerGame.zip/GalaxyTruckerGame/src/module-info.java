/**
 * 
 */
/**
 * @author david
 *
 */
module GalaxyTruckerGame {
}